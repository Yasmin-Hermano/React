

const Menu = () =>{

    require('./Menu.css');

    return(

        <div className="Menu">
            <img src="https://i.imgur.com/RTVb6EB.png"/>
        </div>

    );

}

export default Menu;