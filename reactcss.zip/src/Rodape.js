
const Rodape = () => {


    require('./Rodape.css');

    return(
    <div>

    <div className='Rodape'> 
        <ul>
            <p> Hedenilson Charles</p>
            <p>Dhandara Rafaela</p>
            <p>Yasmin Hermano</p>
            <p>Vinícius Gabriel</p>

        </ul>
    </div>
    
    </div>
    );


}

export default Rodape;