
const Rodape = () => {


    require('./Rodape.css');

    return(
        <footer className="Rodape">
            <ul>
                <li>Hedenilson Charles</li>
                <li>Dhandara Rafaela</li>
                <li>Yasmin Hermano</li>
                <li>Vinícius Gabriel</li>
            </ul>
        </footer>
    );


}

export default Rodape;